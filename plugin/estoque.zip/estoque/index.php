<?php
/*
Plugin Name: Controle de Estoque
Description: CRUD de Controle de Estoque baseado em custom post types do wordpress
Version: 1.1
Author: Nelson Campos
Author URI: http://nelsoncampos.com.br
*/


require('cria-post-types.php');
require('add-meta-box.php');
require('funcoes-extras.php');






